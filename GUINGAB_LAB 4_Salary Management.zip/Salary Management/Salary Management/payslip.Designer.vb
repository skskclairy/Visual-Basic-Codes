﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Payslip
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DaysWLabel = New System.Windows.Forms.Label()
        Me.ndwLabel = New System.Windows.Forms.TextBox()
        Me.rateLabel = New System.Windows.Forms.Label()
        Me.rLabel = New System.Windows.Forms.TextBox()
        Me.buttonTableLayout = New System.Windows.Forms.TableLayoutPanel()
        Me.calcButton = New System.Windows.Forms.Button()
        Me.exitButton = New System.Windows.Forms.Button()
        Me.clearButton = New System.Windows.Forms.Button()
        Me.deducTableLayout = New System.Windows.Forms.TableLayoutPanel()
        Me.totalDeducLabel = New System.Windows.Forms.Label()
        Me.tLabel = New System.Windows.Forms.Label()
        Me.piLabel = New System.Windows.Forms.Label()
        Me.phLabel = New System.Windows.Forms.Label()
        Me.totalDLabel = New System.Windows.Forms.Label()
        Me.SSSLabel = New System.Windows.Forms.Label()
        Me.philLabel = New System.Windows.Forms.Label()
        Me.pagIbigLabel = New System.Windows.Forms.Label()
        Me.TaxLabel = New System.Windows.Forms.Label()
        Me.sLabel = New System.Windows.Forms.Label()
        Me.deducLabel = New System.Windows.Forms.Label()
        Me.gnTableLayout = New System.Windows.Forms.TableLayoutPanel()
        Me.gPay = New System.Windows.Forms.Label()
        Me.nPay = New System.Windows.Forms.Label()
        Me.gpayLabel = New System.Windows.Forms.Label()
        Me.npayLabel = New System.Windows.Forms.Label()
        Me.deducGroupBox = New System.Windows.Forms.GroupBox()
        Me.designPictureBox = New System.Windows.Forms.PictureBox()
        Me.buttonTableLayout.SuspendLayout()
        Me.deducTableLayout.SuspendLayout()
        Me.gnTableLayout.SuspendLayout()
        Me.deducGroupBox.SuspendLayout()
        CType(Me.designPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DaysWLabel
        '
        Me.DaysWLabel.AutoSize = True
        Me.DaysWLabel.BackColor = System.Drawing.Color.Transparent
        Me.DaysWLabel.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DaysWLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.DaysWLabel.Location = New System.Drawing.Point(12, 141)
        Me.DaysWLabel.Name = "DaysWLabel"
        Me.DaysWLabel.Size = New System.Drawing.Size(107, 15)
        Me.DaysWLabel.TabIndex = 27
        Me.DaysWLabel.Text = "No. of Days Work: "
        '
        'ndwLabel
        '
        Me.ndwLabel.BackColor = System.Drawing.Color.White
        Me.ndwLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ndwLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ndwLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(197, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.ndwLabel.Location = New System.Drawing.Point(116, 140)
        Me.ndwLabel.Name = "ndwLabel"
        Me.ndwLabel.Size = New System.Drawing.Size(53, 22)
        Me.ndwLabel.TabIndex = 1
        '
        'rateLabel
        '
        Me.rateLabel.AutoSize = True
        Me.rateLabel.BackColor = System.Drawing.Color.Transparent
        Me.rateLabel.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rateLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.rateLabel.Location = New System.Drawing.Point(175, 141)
        Me.rateLabel.Name = "rateLabel"
        Me.rateLabel.Size = New System.Drawing.Size(83, 15)
        Me.rateLabel.TabIndex = 29
        Me.rateLabel.Text = "Rate per day: "
        '
        'rLabel
        '
        Me.rLabel.BackColor = System.Drawing.Color.White
        Me.rLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.rLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(197, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.rLabel.Location = New System.Drawing.Point(253, 140)
        Me.rLabel.Name = "rLabel"
        Me.rLabel.Size = New System.Drawing.Size(53, 22)
        Me.rLabel.TabIndex = 2
        '
        'buttonTableLayout
        '
        Me.buttonTableLayout.BackColor = System.Drawing.Color.Transparent
        Me.buttonTableLayout.ColumnCount = 3
        Me.buttonTableLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.21875!))
        Me.buttonTableLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.78125!))
        Me.buttonTableLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 105.0!))
        Me.buttonTableLayout.Controls.Add(Me.calcButton, 0, 0)
        Me.buttonTableLayout.Controls.Add(Me.exitButton, 1, 0)
        Me.buttonTableLayout.Controls.Add(Me.clearButton, 2, 0)
        Me.buttonTableLayout.Location = New System.Drawing.Point(16, 355)
        Me.buttonTableLayout.Name = "buttonTableLayout"
        Me.buttonTableLayout.RowCount = 1
        Me.buttonTableLayout.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.buttonTableLayout.Size = New System.Drawing.Size(293, 30)
        Me.buttonTableLayout.TabIndex = 31
        '
        'calcButton
        '
        Me.calcButton.BackColor = System.Drawing.Color.Transparent
        Me.calcButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.calcButton.Location = New System.Drawing.Point(3, 3)
        Me.calcButton.Name = "calcButton"
        Me.calcButton.Size = New System.Drawing.Size(86, 23)
        Me.calcButton.TabIndex = 3
        Me.calcButton.Text = "&Calculate"
        Me.calcButton.UseVisualStyleBackColor = False
        '
        'exitButton
        '
        Me.exitButton.BackColor = System.Drawing.Color.Transparent
        Me.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.exitButton.Location = New System.Drawing.Point(95, 3)
        Me.exitButton.Name = "exitButton"
        Me.exitButton.Size = New System.Drawing.Size(89, 23)
        Me.exitButton.TabIndex = 5
        Me.exitButton.Text = "&Exit"
        Me.exitButton.UseVisualStyleBackColor = False
        '
        'clearButton
        '
        Me.clearButton.BackColor = System.Drawing.Color.Transparent
        Me.clearButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.clearButton.Location = New System.Drawing.Point(190, 3)
        Me.clearButton.Name = "clearButton"
        Me.clearButton.Size = New System.Drawing.Size(99, 23)
        Me.clearButton.TabIndex = 4
        Me.clearButton.Text = "Clea&r Screen"
        Me.clearButton.UseVisualStyleBackColor = False
        '
        'deducTableLayout
        '
        Me.deducTableLayout.ColumnCount = 2
        Me.deducTableLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.15686!))
        Me.deducTableLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.84314!))
        Me.deducTableLayout.Controls.Add(Me.totalDeducLabel, 1, 4)
        Me.deducTableLayout.Controls.Add(Me.tLabel, 1, 3)
        Me.deducTableLayout.Controls.Add(Me.piLabel, 1, 2)
        Me.deducTableLayout.Controls.Add(Me.phLabel, 1, 1)
        Me.deducTableLayout.Controls.Add(Me.totalDLabel, 0, 4)
        Me.deducTableLayout.Controls.Add(Me.SSSLabel, 0, 0)
        Me.deducTableLayout.Controls.Add(Me.philLabel, 0, 1)
        Me.deducTableLayout.Controls.Add(Me.pagIbigLabel, 0, 2)
        Me.deducTableLayout.Controls.Add(Me.TaxLabel, 0, 3)
        Me.deducTableLayout.Controls.Add(Me.sLabel, 1, 0)
        Me.deducTableLayout.Location = New System.Drawing.Point(32, 33)
        Me.deducTableLayout.Name = "deducTableLayout"
        Me.deducTableLayout.RowCount = 5
        Me.deducTableLayout.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.93877!))
        Me.deducTableLayout.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.06123!))
        Me.deducTableLayout.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21.0!))
        Me.deducTableLayout.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.deducTableLayout.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21.0!))
        Me.deducTableLayout.Size = New System.Drawing.Size(204, 98)
        Me.deducTableLayout.TabIndex = 32
        '
        'totalDeducLabel
        '
        Me.totalDeducLabel.AutoSize = True
        Me.totalDeducLabel.BackColor = System.Drawing.Color.Transparent
        Me.totalDeducLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalDeducLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(197, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.totalDeducLabel.Location = New System.Drawing.Point(139, 76)
        Me.totalDeducLabel.Name = "totalDeducLabel"
        Me.totalDeducLabel.Size = New System.Drawing.Size(15, 16)
        Me.totalDeducLabel.TabIndex = 42
        Me.totalDeducLabel.Text = "0"
        '
        'tLabel
        '
        Me.tLabel.AutoSize = True
        Me.tLabel.BackColor = System.Drawing.Color.Transparent
        Me.tLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(197, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.tLabel.Location = New System.Drawing.Point(139, 56)
        Me.tLabel.Name = "tLabel"
        Me.tLabel.Size = New System.Drawing.Size(15, 16)
        Me.tLabel.TabIndex = 41
        Me.tLabel.Text = "0"
        '
        'piLabel
        '
        Me.piLabel.AutoSize = True
        Me.piLabel.BackColor = System.Drawing.Color.Transparent
        Me.piLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.piLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(197, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.piLabel.Location = New System.Drawing.Point(139, 35)
        Me.piLabel.Name = "piLabel"
        Me.piLabel.Size = New System.Drawing.Size(15, 16)
        Me.piLabel.TabIndex = 40
        Me.piLabel.Text = "0"
        '
        'phLabel
        '
        Me.phLabel.AutoSize = True
        Me.phLabel.BackColor = System.Drawing.Color.Transparent
        Me.phLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.phLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(197, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.phLabel.Location = New System.Drawing.Point(139, 16)
        Me.phLabel.Name = "phLabel"
        Me.phLabel.Size = New System.Drawing.Size(15, 16)
        Me.phLabel.TabIndex = 39
        Me.phLabel.Text = "0"
        '
        'totalDLabel
        '
        Me.totalDLabel.AutoSize = True
        Me.totalDLabel.BackColor = System.Drawing.Color.Transparent
        Me.totalDLabel.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalDLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.totalDLabel.Location = New System.Drawing.Point(3, 76)
        Me.totalDLabel.Name = "totalDLabel"
        Me.totalDLabel.Size = New System.Drawing.Size(122, 19)
        Me.totalDLabel.TabIndex = 38
        Me.totalDLabel.Text = "Total Deductions:"
        '
        'SSSLabel
        '
        Me.SSSLabel.BackColor = System.Drawing.Color.Transparent
        Me.SSSLabel.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SSSLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.SSSLabel.Location = New System.Drawing.Point(3, 0)
        Me.SSSLabel.Name = "SSSLabel"
        Me.SSSLabel.Size = New System.Drawing.Size(90, 16)
        Me.SSSLabel.TabIndex = 34
        Me.SSSLabel.Text = "SSS: "
        '
        'philLabel
        '
        Me.philLabel.AutoSize = True
        Me.philLabel.BackColor = System.Drawing.Color.Transparent
        Me.philLabel.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.philLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.philLabel.Location = New System.Drawing.Point(3, 16)
        Me.philLabel.Name = "philLabel"
        Me.philLabel.Size = New System.Drawing.Size(84, 19)
        Me.philLabel.TabIndex = 35
        Me.philLabel.Text = "PhilHealth: "
        '
        'pagIbigLabel
        '
        Me.pagIbigLabel.AutoSize = True
        Me.pagIbigLabel.BackColor = System.Drawing.Color.Transparent
        Me.pagIbigLabel.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pagIbigLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.pagIbigLabel.Location = New System.Drawing.Point(3, 35)
        Me.pagIbigLabel.Name = "pagIbigLabel"
        Me.pagIbigLabel.Size = New System.Drawing.Size(61, 19)
        Me.pagIbigLabel.TabIndex = 36
        Me.pagIbigLabel.Text = "PagIbig:"
        '
        'TaxLabel
        '
        Me.TaxLabel.AutoSize = True
        Me.TaxLabel.BackColor = System.Drawing.Color.Transparent
        Me.TaxLabel.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TaxLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.TaxLabel.Location = New System.Drawing.Point(3, 56)
        Me.TaxLabel.Name = "TaxLabel"
        Me.TaxLabel.Size = New System.Drawing.Size(37, 19)
        Me.TaxLabel.TabIndex = 37
        Me.TaxLabel.Text = "TAX:"
        '
        'sLabel
        '
        Me.sLabel.AutoSize = True
        Me.sLabel.BackColor = System.Drawing.Color.Transparent
        Me.sLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(197, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.sLabel.Location = New System.Drawing.Point(139, 0)
        Me.sLabel.Name = "sLabel"
        Me.sLabel.Size = New System.Drawing.Size(15, 16)
        Me.sLabel.TabIndex = 34
        Me.sLabel.Text = "0"
        '
        'deducLabel
        '
        Me.deducLabel.AutoSize = True
        Me.deducLabel.BackColor = System.Drawing.Color.Transparent
        Me.deducLabel.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deducLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.deducLabel.Location = New System.Drawing.Point(17, 11)
        Me.deducLabel.Name = "deducLabel"
        Me.deducLabel.Size = New System.Drawing.Size(86, 19)
        Me.deducLabel.TabIndex = 33
        Me.deducLabel.Text = "Deductions:"
        '
        'gnTableLayout
        '
        Me.gnTableLayout.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gnTableLayout.ColumnCount = 2
        Me.gnTableLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.gnTableLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.gnTableLayout.Controls.Add(Me.gPay, 0, 0)
        Me.gnTableLayout.Controls.Add(Me.nPay, 1, 0)
        Me.gnTableLayout.Controls.Add(Me.gpayLabel, 0, 1)
        Me.gnTableLayout.Controls.Add(Me.npayLabel, 1, 1)
        Me.gnTableLayout.Location = New System.Drawing.Point(32, 137)
        Me.gnTableLayout.Name = "gnTableLayout"
        Me.gnTableLayout.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.gnTableLayout.RowCount = 2
        Me.gnTableLayout.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.gnTableLayout.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.gnTableLayout.Size = New System.Drawing.Size(181, 40)
        Me.gnTableLayout.TabIndex = 34
        '
        'gPay
        '
        Me.gPay.AutoSize = True
        Me.gPay.BackColor = System.Drawing.Color.Transparent
        Me.gPay.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gPay.ForeColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.gPay.Location = New System.Drawing.Point(3, 0)
        Me.gPay.Name = "gPay"
        Me.gPay.Size = New System.Drawing.Size(77, 19)
        Me.gPay.TabIndex = 39
        Me.gPay.Text = "Gross Pay:"
        Me.gPay.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'nPay
        '
        Me.nPay.AutoSize = True
        Me.nPay.BackColor = System.Drawing.Color.Transparent
        Me.nPay.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nPay.ForeColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.nPay.Location = New System.Drawing.Point(93, 0)
        Me.nPay.Name = "nPay"
        Me.nPay.Size = New System.Drawing.Size(63, 19)
        Me.nPay.TabIndex = 40
        Me.nPay.Text = "Net Pay:"
        '
        'gpayLabel
        '
        Me.gpayLabel.AutoSize = True
        Me.gpayLabel.BackColor = System.Drawing.Color.Transparent
        Me.gpayLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gpayLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(197, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.gpayLabel.Location = New System.Drawing.Point(3, 20)
        Me.gpayLabel.Name = "gpayLabel"
        Me.gpayLabel.Size = New System.Drawing.Size(15, 16)
        Me.gpayLabel.TabIndex = 42
        Me.gpayLabel.Text = "0"
        '
        'npayLabel
        '
        Me.npayLabel.AutoSize = True
        Me.npayLabel.BackColor = System.Drawing.Color.Transparent
        Me.npayLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.npayLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(197, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(93, Byte), Integer))
        Me.npayLabel.Location = New System.Drawing.Point(93, 20)
        Me.npayLabel.Name = "npayLabel"
        Me.npayLabel.Size = New System.Drawing.Size(15, 16)
        Me.npayLabel.TabIndex = 43
        Me.npayLabel.Text = "0"
        '
        'deducGroupBox
        '
        Me.deducGroupBox.Controls.Add(Me.gnTableLayout)
        Me.deducGroupBox.Controls.Add(Me.deducLabel)
        Me.deducGroupBox.Controls.Add(Me.deducTableLayout)
        Me.deducGroupBox.Location = New System.Drawing.Point(12, 166)
        Me.deducGroupBox.Name = "deducGroupBox"
        Me.deducGroupBox.Size = New System.Drawing.Size(297, 183)
        Me.deducGroupBox.TabIndex = 35
        Me.deducGroupBox.TabStop = False
        '
        'designPictureBox
        '
        Me.designPictureBox.Image = Global.Salary_Management.My.Resources.Resources._249776634_6398057123570129_5758507127448973655_n
        Me.designPictureBox.Location = New System.Drawing.Point(-10, -3)
        Me.designPictureBox.Name = "designPictureBox"
        Me.designPictureBox.Size = New System.Drawing.Size(343, 141)
        Me.designPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.designPictureBox.TabIndex = 0
        Me.designPictureBox.TabStop = False
        '
        'Payslip
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(323, 395)
        Me.Controls.Add(Me.deducGroupBox)
        Me.Controls.Add(Me.buttonTableLayout)
        Me.Controls.Add(Me.rLabel)
        Me.Controls.Add(Me.rateLabel)
        Me.Controls.Add(Me.ndwLabel)
        Me.Controls.Add(Me.DaysWLabel)
        Me.Controls.Add(Me.designPictureBox)
        Me.Name = "Payslip"
        Me.Text = "Payslip"
        Me.buttonTableLayout.ResumeLayout(False)
        Me.deducTableLayout.ResumeLayout(False)
        Me.deducTableLayout.PerformLayout()
        Me.gnTableLayout.ResumeLayout(False)
        Me.gnTableLayout.PerformLayout()
        Me.deducGroupBox.ResumeLayout(False)
        Me.deducGroupBox.PerformLayout()
        CType(Me.designPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents designPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents DaysWLabel As System.Windows.Forms.Label
    Friend WithEvents ndwLabel As System.Windows.Forms.TextBox
    Friend WithEvents rateLabel As System.Windows.Forms.Label
    Friend WithEvents rLabel As System.Windows.Forms.TextBox
    Friend WithEvents buttonTableLayout As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents calcButton As System.Windows.Forms.Button
    Friend WithEvents exitButton As System.Windows.Forms.Button
    Friend WithEvents clearButton As System.Windows.Forms.Button
    Friend WithEvents deducTableLayout As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents SSSLabel As System.Windows.Forms.Label
    Friend WithEvents deducLabel As System.Windows.Forms.Label
    Friend WithEvents totalDLabel As System.Windows.Forms.Label
    Friend WithEvents philLabel As System.Windows.Forms.Label
    Friend WithEvents pagIbigLabel As System.Windows.Forms.Label
    Friend WithEvents TaxLabel As System.Windows.Forms.Label
    Friend WithEvents totalDeducLabel As System.Windows.Forms.Label
    Friend WithEvents tLabel As System.Windows.Forms.Label
    Friend WithEvents piLabel As System.Windows.Forms.Label
    Friend WithEvents phLabel As System.Windows.Forms.Label
    Friend WithEvents sLabel As System.Windows.Forms.Label
    Friend WithEvents gnTableLayout As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents gPay As System.Windows.Forms.Label
    Friend WithEvents nPay As System.Windows.Forms.Label
    Friend WithEvents gpayLabel As System.Windows.Forms.Label
    Friend WithEvents npayLabel As System.Windows.Forms.Label
    Friend WithEvents deducGroupBox As System.Windows.Forms.GroupBox

End Class
