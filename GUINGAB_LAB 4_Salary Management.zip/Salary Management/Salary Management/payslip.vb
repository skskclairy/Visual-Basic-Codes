﻿Public Class Payslip


    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub

    Private Sub calcButton_Click(sender As Object, e As EventArgs) Handles calcButton.Click

        Dim ndw, rate As Double
        Dim grossPay, netPay, Tax As Double
        Dim totalDeduc, benefits As Double
        Dim sss As Double = 390.0
        Dim pagibig As Double = 200.0
        Dim Philhealth As Double = 350.0

        Double.TryParse(ndwLabel.Text, ndw)
        Double.TryParse(rLabel.Text, rate)

        benefits = sss + pagibig + Philhealth

        grossPay = ndw * rate
        Tax = grossPay * 0.1
        totalDeduc = benefits + Tax
        netPay = grossPay - totalDeduc

        sLabel.Text = Convert.ToString(sss)
        piLabel.Text = Convert.ToString(pagibig)
        phLabel.Text = Convert.ToString(Philhealth)
        tLabel.Text = Convert.ToString(Tax)
        gpayLabel.Text = grossPay.ToString("n")
        npayLabel.Text = netPay.ToString("n")
        totalDeducLabel.Text = totalDeduc.ToString("n")
    End Sub

    Private Sub clearButton_Click(sender As Object, e As EventArgs) Handles clearButton.Click
        sLabel.Text = 0
        piLabel.Text = 0
        phLabel.Text = 0
        tLabel.Text = 0
        gpayLabel.Text = 0
        npayLabel.Text = 0
        totalDeducLabel.Text = 0

        ndwLabel.Clear()
        rLabel.Clear()
    End Sub
End Class
