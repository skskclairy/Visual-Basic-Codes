﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.titleLabel = New System.Windows.Forms.Label()
        Me.inputTableLayoutPanel = New System.Windows.Forms.TableLayoutPanel()
        Me.finalTxtBox = New System.Windows.Forms.TextBox()
        Me.fgradeLabel = New System.Windows.Forms.Label()
        Me.pgradeLabel = New System.Windows.Forms.Label()
        Me.mgradeLabel = New System.Windows.Forms.Label()
        Me.prelimTxtbox = New System.Windows.Forms.TextBox()
        Me.midtermTxtBox = New System.Windows.Forms.TextBox()
        Me.buttonTableLayout = New System.Windows.Forms.TableLayoutPanel()
        Me.calcButton = New System.Windows.Forms.Button()
        Me.exitButton = New System.Windows.Forms.Button()
        Me.clearButton = New System.Windows.Forms.Button()
        Me.outputTableLayoutPanel = New System.Windows.Forms.TableLayoutPanel()
        Me.remarksLabel = New System.Windows.Forms.Label()
        Me.rLabel = New System.Windows.Forms.Label()
        Me.fgLabel = New System.Windows.Forms.Label()
        Me.tLabel = New System.Windows.Forms.Label()
        Me.tfgLabel = New System.Windows.Forms.Label()
        Me.transmutationLabel = New System.Windows.Forms.Label()
        Me.bscsLabel = New System.Windows.Forms.Label()
        Me.inputTableLayoutPanel.SuspendLayout()
        Me.buttonTableLayout.SuspendLayout()
        Me.outputTableLayoutPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'titleLabel
        '
        Me.titleLabel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.titleLabel.AutoSize = True
        Me.titleLabel.BackColor = System.Drawing.Color.Transparent
        Me.titleLabel.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.titleLabel.ForeColor = System.Drawing.Color.White
        Me.titleLabel.Location = New System.Drawing.Point(56, 44)
        Me.titleLabel.Name = "titleLabel"
        Me.titleLabel.Size = New System.Drawing.Size(176, 26)
        Me.titleLabel.TabIndex = 26
        Me.titleLabel.Text = "STUDENT GRADE"
        Me.titleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'inputTableLayoutPanel
        '
        Me.inputTableLayoutPanel.BackColor = System.Drawing.Color.Transparent
        Me.inputTableLayoutPanel.ColumnCount = 2
        Me.inputTableLayoutPanel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.89675!))
        Me.inputTableLayoutPanel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.10324!))
        Me.inputTableLayoutPanel.Controls.Add(Me.finalTxtBox, 1, 2)
        Me.inputTableLayoutPanel.Controls.Add(Me.fgradeLabel, 0, 2)
        Me.inputTableLayoutPanel.Controls.Add(Me.pgradeLabel, 0, 0)
        Me.inputTableLayoutPanel.Controls.Add(Me.mgradeLabel, 0, 1)
        Me.inputTableLayoutPanel.Controls.Add(Me.prelimTxtbox, 1, 0)
        Me.inputTableLayoutPanel.Controls.Add(Me.midtermTxtBox, 1, 1)
        Me.inputTableLayoutPanel.Location = New System.Drawing.Point(21, 70)
        Me.inputTableLayoutPanel.Name = "inputTableLayoutPanel"
        Me.inputTableLayoutPanel.RowCount = 3
        Me.inputTableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.inputTableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.inputTableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29.0!))
        Me.inputTableLayoutPanel.Size = New System.Drawing.Size(228, 82)
        Me.inputTableLayoutPanel.TabIndex = 27
        '
        'finalTxtBox
        '
        Me.finalTxtBox.BackColor = System.Drawing.Color.Silver
        Me.finalTxtBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.finalTxtBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.finalTxtBox.ForeColor = System.Drawing.Color.Black
        Me.finalTxtBox.Location = New System.Drawing.Point(150, 55)
        Me.finalTxtBox.Name = "finalTxtBox"
        Me.finalTxtBox.Size = New System.Drawing.Size(75, 22)
        Me.finalTxtBox.TabIndex = 3
        Me.finalTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'fgradeLabel
        '
        Me.fgradeLabel.AutoSize = True
        Me.fgradeLabel.BackColor = System.Drawing.Color.Transparent
        Me.fgradeLabel.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fgradeLabel.ForeColor = System.Drawing.Color.White
        Me.fgradeLabel.Location = New System.Drawing.Point(3, 52)
        Me.fgradeLabel.Name = "fgradeLabel"
        Me.fgradeLabel.Size = New System.Drawing.Size(105, 23)
        Me.fgradeLabel.TabIndex = 29
        Me.fgradeLabel.Text = "Final Grade:"
        '
        'pgradeLabel
        '
        Me.pgradeLabel.AutoSize = True
        Me.pgradeLabel.BackColor = System.Drawing.Color.Transparent
        Me.pgradeLabel.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pgradeLabel.ForeColor = System.Drawing.Color.White
        Me.pgradeLabel.Location = New System.Drawing.Point(3, 0)
        Me.pgradeLabel.Name = "pgradeLabel"
        Me.pgradeLabel.Size = New System.Drawing.Size(119, 23)
        Me.pgradeLabel.TabIndex = 28
        Me.pgradeLabel.Text = "Prelim Grade:"
        '
        'mgradeLabel
        '
        Me.mgradeLabel.AutoSize = True
        Me.mgradeLabel.BackColor = System.Drawing.Color.Transparent
        Me.mgradeLabel.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mgradeLabel.ForeColor = System.Drawing.Color.White
        Me.mgradeLabel.Location = New System.Drawing.Point(3, 26)
        Me.mgradeLabel.Name = "mgradeLabel"
        Me.mgradeLabel.Size = New System.Drawing.Size(138, 23)
        Me.mgradeLabel.TabIndex = 29
        Me.mgradeLabel.Text = "Midterm Grade:"
        '
        'prelimTxtbox
        '
        Me.prelimTxtbox.BackColor = System.Drawing.Color.Silver
        Me.prelimTxtbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.prelimTxtbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.prelimTxtbox.ForeColor = System.Drawing.Color.Black
        Me.prelimTxtbox.Location = New System.Drawing.Point(150, 3)
        Me.prelimTxtbox.Name = "prelimTxtbox"
        Me.prelimTxtbox.Size = New System.Drawing.Size(75, 22)
        Me.prelimTxtbox.TabIndex = 1
        Me.prelimTxtbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'midtermTxtBox
        '
        Me.midtermTxtBox.BackColor = System.Drawing.Color.Silver
        Me.midtermTxtBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.midtermTxtBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.midtermTxtBox.ForeColor = System.Drawing.Color.Black
        Me.midtermTxtBox.Location = New System.Drawing.Point(150, 29)
        Me.midtermTxtBox.Name = "midtermTxtBox"
        Me.midtermTxtBox.Size = New System.Drawing.Size(75, 22)
        Me.midtermTxtBox.TabIndex = 2
        Me.midtermTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'buttonTableLayout
        '
        Me.buttonTableLayout.BackColor = System.Drawing.Color.Transparent
        Me.buttonTableLayout.ColumnCount = 3
        Me.buttonTableLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.21875!))
        Me.buttonTableLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.78125!))
        Me.buttonTableLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96.0!))
        Me.buttonTableLayout.Controls.Add(Me.calcButton, 0, 0)
        Me.buttonTableLayout.Controls.Add(Me.exitButton, 2, 0)
        Me.buttonTableLayout.Controls.Add(Me.clearButton, 1, 0)
        Me.buttonTableLayout.Location = New System.Drawing.Point(1, 246)
        Me.buttonTableLayout.Name = "buttonTableLayout"
        Me.buttonTableLayout.RowCount = 1
        Me.buttonTableLayout.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.buttonTableLayout.Size = New System.Drawing.Size(289, 35)
        Me.buttonTableLayout.TabIndex = 32
        '
        'calcButton
        '
        Me.calcButton.BackColor = System.Drawing.Color.Transparent
        Me.calcButton.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.calcButton.Location = New System.Drawing.Point(3, 3)
        Me.calcButton.Name = "calcButton"
        Me.calcButton.Size = New System.Drawing.Size(88, 23)
        Me.calcButton.TabIndex = 4
        Me.calcButton.Text = "&Calculate"
        Me.calcButton.UseVisualStyleBackColor = False
        '
        'exitButton
        '
        Me.exitButton.BackColor = System.Drawing.Color.Transparent
        Me.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.exitButton.Location = New System.Drawing.Point(195, 3)
        Me.exitButton.Name = "exitButton"
        Me.exitButton.Size = New System.Drawing.Size(84, 23)
        Me.exitButton.TabIndex = 6
        Me.exitButton.Text = "&Exit"
        Me.exitButton.UseVisualStyleBackColor = False
        '
        'clearButton
        '
        Me.clearButton.BackColor = System.Drawing.Color.Transparent
        Me.clearButton.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.clearButton.Location = New System.Drawing.Point(97, 3)
        Me.clearButton.Name = "clearButton"
        Me.clearButton.Size = New System.Drawing.Size(92, 23)
        Me.clearButton.TabIndex = 5
        Me.clearButton.Text = "Clea&r Screen"
        Me.clearButton.UseVisualStyleBackColor = False
        '
        'outputTableLayoutPanel
        '
        Me.outputTableLayoutPanel.BackColor = System.Drawing.Color.Transparent
        Me.outputTableLayoutPanel.ColumnCount = 2
        Me.outputTableLayoutPanel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.10781!))
        Me.outputTableLayoutPanel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.89219!))
        Me.outputTableLayoutPanel.Controls.Add(Me.remarksLabel, 1, 2)
        Me.outputTableLayoutPanel.Controls.Add(Me.rLabel, 0, 2)
        Me.outputTableLayoutPanel.Controls.Add(Me.fgLabel, 0, 0)
        Me.outputTableLayoutPanel.Controls.Add(Me.tLabel, 0, 1)
        Me.outputTableLayoutPanel.Controls.Add(Me.tfgLabel, 1, 0)
        Me.outputTableLayoutPanel.Controls.Add(Me.transmutationLabel, 1, 1)
        Me.outputTableLayoutPanel.Location = New System.Drawing.Point(21, 158)
        Me.outputTableLayoutPanel.Name = "outputTableLayoutPanel"
        Me.outputTableLayoutPanel.RowCount = 3
        Me.outputTableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.outputTableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.outputTableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29.0!))
        Me.outputTableLayoutPanel.Size = New System.Drawing.Size(269, 82)
        Me.outputTableLayoutPanel.TabIndex = 33
        '
        'remarksLabel
        '
        Me.remarksLabel.AutoSize = True
        Me.remarksLabel.BackColor = System.Drawing.Color.Transparent
        Me.remarksLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.remarksLabel.ForeColor = System.Drawing.Color.White
        Me.remarksLabel.Location = New System.Drawing.Point(162, 52)
        Me.remarksLabel.Name = "remarksLabel"
        Me.remarksLabel.Size = New System.Drawing.Size(35, 20)
        Me.remarksLabel.TabIndex = 37
        Me.remarksLabel.Text = "N/A"
        '
        'rLabel
        '
        Me.rLabel.AutoSize = True
        Me.rLabel.BackColor = System.Drawing.Color.Transparent
        Me.rLabel.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rLabel.ForeColor = System.Drawing.Color.White
        Me.rLabel.Location = New System.Drawing.Point(3, 52)
        Me.rLabel.Name = "rLabel"
        Me.rLabel.Size = New System.Drawing.Size(84, 23)
        Me.rLabel.TabIndex = 29
        Me.rLabel.Text = "Remarks:"
        '
        'fgLabel
        '
        Me.fgLabel.AutoSize = True
        Me.fgLabel.BackColor = System.Drawing.Color.Transparent
        Me.fgLabel.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fgLabel.ForeColor = System.Drawing.Color.White
        Me.fgLabel.Location = New System.Drawing.Point(3, 0)
        Me.fgLabel.Name = "fgLabel"
        Me.fgLabel.Size = New System.Drawing.Size(147, 23)
        Me.fgLabel.TabIndex = 28
        Me.fgLabel.Text = "Total Final Grade:"
        '
        'tLabel
        '
        Me.tLabel.AutoSize = True
        Me.tLabel.BackColor = System.Drawing.Color.Transparent
        Me.tLabel.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tLabel.ForeColor = System.Drawing.Color.White
        Me.tLabel.Location = New System.Drawing.Point(3, 26)
        Me.tLabel.Name = "tLabel"
        Me.tLabel.Size = New System.Drawing.Size(129, 23)
        Me.tLabel.TabIndex = 29
        Me.tLabel.Text = "Transmutation:"
        '
        'tfgLabel
        '
        Me.tfgLabel.AutoSize = True
        Me.tfgLabel.BackColor = System.Drawing.Color.Transparent
        Me.tfgLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tfgLabel.ForeColor = System.Drawing.Color.White
        Me.tfgLabel.Location = New System.Drawing.Point(162, 0)
        Me.tfgLabel.Name = "tfgLabel"
        Me.tfgLabel.Size = New System.Drawing.Size(35, 20)
        Me.tfgLabel.TabIndex = 35
        Me.tfgLabel.Text = "N/A"
        '
        'transmutationLabel
        '
        Me.transmutationLabel.AutoSize = True
        Me.transmutationLabel.BackColor = System.Drawing.Color.Transparent
        Me.transmutationLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.transmutationLabel.ForeColor = System.Drawing.Color.White
        Me.transmutationLabel.Location = New System.Drawing.Point(162, 26)
        Me.transmutationLabel.Name = "transmutationLabel"
        Me.transmutationLabel.Size = New System.Drawing.Size(35, 20)
        Me.transmutationLabel.TabIndex = 36
        Me.transmutationLabel.Text = "N/A"
        '
        'bscsLabel
        '
        Me.bscsLabel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.bscsLabel.AutoSize = True
        Me.bscsLabel.BackColor = System.Drawing.Color.Transparent
        Me.bscsLabel.Font = New System.Drawing.Font("Comic Sans MS", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bscsLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.bscsLabel.Location = New System.Drawing.Point(40, 0)
        Me.bscsLabel.Name = "bscsLabel"
        Me.bscsLabel.Size = New System.Drawing.Size(228, 29)
        Me.bscsLabel.TabIndex = 34
        Me.bscsLabel.Text = "BS Computer Science "
        Me.bscsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Laboratory_5.My.Resources.Resources.black_1072366__480
        Me.ClientSize = New System.Drawing.Size(295, 289)
        Me.Controls.Add(Me.bscsLabel)
        Me.Controls.Add(Me.outputTableLayoutPanel)
        Me.Controls.Add(Me.buttonTableLayout)
        Me.Controls.Add(Me.inputTableLayoutPanel)
        Me.Controls.Add(Me.titleLabel)
        Me.Name = "Form1"
        Me.Text = "Grade Calculator"
        Me.inputTableLayoutPanel.ResumeLayout(False)
        Me.inputTableLayoutPanel.PerformLayout()
        Me.buttonTableLayout.ResumeLayout(False)
        Me.outputTableLayoutPanel.ResumeLayout(False)
        Me.outputTableLayoutPanel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents titleLabel As System.Windows.Forms.Label
    Friend WithEvents inputTableLayoutPanel As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents finalTxtBox As System.Windows.Forms.TextBox
    Friend WithEvents midtermTxtBox As System.Windows.Forms.TextBox
    Friend WithEvents fgradeLabel As System.Windows.Forms.Label
    Friend WithEvents pgradeLabel As System.Windows.Forms.Label
    Friend WithEvents mgradeLabel As System.Windows.Forms.Label
    Friend WithEvents prelimTxtbox As System.Windows.Forms.TextBox
    Friend WithEvents buttonTableLayout As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents calcButton As System.Windows.Forms.Button
    Friend WithEvents exitButton As System.Windows.Forms.Button
    Friend WithEvents clearButton As System.Windows.Forms.Button
    Friend WithEvents outputTableLayoutPanel As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents rLabel As System.Windows.Forms.Label
    Friend WithEvents fgLabel As System.Windows.Forms.Label
    Friend WithEvents tLabel As System.Windows.Forms.Label
    Friend WithEvents tfgLabel As System.Windows.Forms.Label
    Friend WithEvents remarksLabel As System.Windows.Forms.Label
    Friend WithEvents transmutationLabel As System.Windows.Forms.Label
    Friend WithEvents bscsLabel As System.Windows.Forms.Label

End Class
