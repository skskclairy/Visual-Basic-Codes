﻿Public Class Form1


    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub

    Private Sub clearButton_Click(sender As Object, e As EventArgs) Handles clearButton.Click
        prelimTxtbox.Clear()
        midtermTxtBox.Clear()
        finalTxtBox.Clear()

        tfgLabel.Text = "N/A"
        transmutationLabel.Text = "N/A"
        remarksLabel.Text = "N/A"

    End Sub

    Private Sub calcButton_Click(sender As Object, e As EventArgs) Handles calcButton.Click
        Dim PG, MG, FG, TFG As Double

        Double.TryParse(prelimTxtbox.Text, PG)
        Double.TryParse(midtermTxtBox.Text, MG)
        Double.TryParse(finalTxtBox.Text, FG)

        TFG = (PG * 0.3) + (MG * 0.3) + (FG * 0.4)

        If Double.TryParse(prelimTxtbox.Text, PG) <> True OrElse Double.TryParse(midtermTxtBox.Text, MG) <> True OrElse Double.TryParse(finalTxtBox.Text, FG) <> True Then
            MessageBox.Show("Unknown input")
            prelimTxtbox.Clear()
            midtermTxtBox.Clear()
            finalTxtBox.Clear()
        Else
            tfgLabel.Text = TFG.ToString("n")
            If TFG <= 74 Then
                transmutationLabel.Text = "5.0"
                remarksLabel.Text = "FAILED"
            ElseIf TFG <= 76 Then
                transmutationLabel.Text = "3.0"
                remarksLabel.Text = "PASSED"
            ElseIf TFG <= 79 Then
                transmutationLabel.Text = "2.75"
                remarksLabel.Text = "PASSED"
            ElseIf TFG <= 82 Then
                transmutationLabel.Text = "2.50"
                remarksLabel.Text = "PASSED"
            ElseIf TFG <= 85 Then
                transmutationLabel.Text = "2.25"
                remarksLabel.Text = "PASSED"
            ElseIf TFG <= 88 Then
                transmutationLabel.Text = "2.0"
                remarksLabel.Text = "PASSED"
            ElseIf TFG <= 91 Then
                transmutationLabel.Text = "1.75"
                remarksLabel.Text = "PASSED"
            ElseIf TFG <= 94 Then
                transmutationLabel.Text = "1.50"
                remarksLabel.Text = "PASSED"
            ElseIf TFG <= 97 Then
                transmutationLabel.Text = "1.25"
                remarksLabel.Text = "PASSED"
            ElseIf TFG <= 100 Then
                transmutationLabel.Text = "1.0"
                remarksLabel.Text = "PASSED"
            Else
                transmutationLabel.Text = "Invalid input"
            End If
        End If

    End Sub
End Class
