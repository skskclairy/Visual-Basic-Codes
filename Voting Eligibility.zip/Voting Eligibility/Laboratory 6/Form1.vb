﻿Public Class Form1

    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub

    Private Sub clearButton_Click(sender As Object, e As EventArgs) Handles clearButton.Click
        ageTxtbox.Clear()
        rsltLbl.Text = "Result"
    End Sub

    Private Sub submitButton_Click(sender As Object, e As EventArgs) Handles submitButton.Click
        Dim age As Integer

        Integer.TryParse(ageTxtbox.Text, age)

        If age >= 18 Then
            rsltLbl.Text = "Eligible to vote"
        ElseIf age < 18 Then
            rsltLbl.Text = "Too young to vote"
        Else
            rsltLbl.Text = "INVALID AGE"
        End If

    End Sub

End Class
