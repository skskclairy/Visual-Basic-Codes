﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ageLabel = New System.Windows.Forms.Label()
        Me.ageTxtbox = New System.Windows.Forms.TextBox()
        Me.buttonTableLayout = New System.Windows.Forms.TableLayoutPanel()
        Me.exitButton = New System.Windows.Forms.Button()
        Me.submitButton = New System.Windows.Forms.Button()
        Me.clearButton = New System.Windows.Forms.Button()
        Me.rsltLbl = New System.Windows.Forms.Label()
        Me.vePictureBox = New System.Windows.Forms.PictureBox()
        Me.buttonTableLayout.SuspendLayout()
        CType(Me.vePictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ageLabel
        '
        Me.ageLabel.AutoSize = True
        Me.ageLabel.BackColor = System.Drawing.Color.Transparent
        Me.ageLabel.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ageLabel.ForeColor = System.Drawing.Color.Black
        Me.ageLabel.Location = New System.Drawing.Point(57, 80)
        Me.ageLabel.Name = "ageLabel"
        Me.ageLabel.Size = New System.Drawing.Size(46, 23)
        Me.ageLabel.TabIndex = 29
        Me.ageLabel.Text = "Age:"
        '
        'ageTxtbox
        '
        Me.ageTxtbox.BackColor = System.Drawing.Color.Silver
        Me.ageTxtbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ageTxtbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ageTxtbox.ForeColor = System.Drawing.Color.Black
        Me.ageTxtbox.Location = New System.Drawing.Point(143, 80)
        Me.ageTxtbox.Name = "ageTxtbox"
        Me.ageTxtbox.Size = New System.Drawing.Size(75, 22)
        Me.ageTxtbox.TabIndex = 1
        Me.ageTxtbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'buttonTableLayout
        '
        Me.buttonTableLayout.BackColor = System.Drawing.Color.Transparent
        Me.buttonTableLayout.ColumnCount = 3
        Me.buttonTableLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.21875!))
        Me.buttonTableLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.78125!))
        Me.buttonTableLayout.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 102.0!))
        Me.buttonTableLayout.Controls.Add(Me.exitButton, 2, 0)
        Me.buttonTableLayout.Controls.Add(Me.submitButton, 0, 0)
        Me.buttonTableLayout.Controls.Add(Me.clearButton, 1, 0)
        Me.buttonTableLayout.Location = New System.Drawing.Point(1, 158)
        Me.buttonTableLayout.Name = "buttonTableLayout"
        Me.buttonTableLayout.RowCount = 1
        Me.buttonTableLayout.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.buttonTableLayout.Size = New System.Drawing.Size(289, 27)
        Me.buttonTableLayout.TabIndex = 37
        '
        'exitButton
        '
        Me.exitButton.BackColor = System.Drawing.Color.Transparent
        Me.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.exitButton.Location = New System.Drawing.Point(189, 3)
        Me.exitButton.Name = "exitButton"
        Me.exitButton.Size = New System.Drawing.Size(84, 21)
        Me.exitButton.TabIndex = 4
        Me.exitButton.Text = "&Exit"
        Me.exitButton.UseVisualStyleBackColor = False
        '
        'submitButton
        '
        Me.submitButton.BackColor = System.Drawing.Color.Transparent
        Me.submitButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.submitButton.Location = New System.Drawing.Point(3, 3)
        Me.submitButton.Name = "submitButton"
        Me.submitButton.Size = New System.Drawing.Size(86, 21)
        Me.submitButton.TabIndex = 2
        Me.submitButton.Text = "&Submit"
        Me.submitButton.UseVisualStyleBackColor = False
        '
        'clearButton
        '
        Me.clearButton.BackColor = System.Drawing.Color.Transparent
        Me.clearButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.clearButton.Location = New System.Drawing.Point(95, 3)
        Me.clearButton.Name = "clearButton"
        Me.clearButton.Size = New System.Drawing.Size(88, 21)
        Me.clearButton.TabIndex = 3
        Me.clearButton.Text = "Clea&r Screen"
        Me.clearButton.UseVisualStyleBackColor = False
        '
        'rsltLbl
        '
        Me.rsltLbl.AutoSize = True
        Me.rsltLbl.BackColor = System.Drawing.Color.Transparent
        Me.rsltLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rsltLbl.Location = New System.Drawing.Point(57, 124)
        Me.rsltLbl.Name = "rsltLbl"
        Me.rsltLbl.Size = New System.Drawing.Size(61, 20)
        Me.rsltLbl.TabIndex = 38
        Me.rsltLbl.Text = "Result"
        Me.rsltLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'vePictureBox
        '
        Me.vePictureBox.Image = Global.Laboratory_6.My.Resources.Resources._260214390_315938303711777_7017579353511731958_n
        Me.vePictureBox.Location = New System.Drawing.Point(-20, -8)
        Me.vePictureBox.Name = "vePictureBox"
        Me.vePictureBox.Size = New System.Drawing.Size(326, 85)
        Me.vePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.vePictureBox.TabIndex = 39
        Me.vePictureBox.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(287, 188)
        Me.Controls.Add(Me.rsltLbl)
        Me.Controls.Add(Me.buttonTableLayout)
        Me.Controls.Add(Me.ageTxtbox)
        Me.Controls.Add(Me.ageLabel)
        Me.Controls.Add(Me.vePictureBox)
        Me.DoubleBuffered = True
        Me.Name = "Form1"
        Me.Text = "Voter Eligibility"
        Me.buttonTableLayout.ResumeLayout(False)
        CType(Me.vePictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ageLabel As System.Windows.Forms.Label
    Friend WithEvents ageTxtbox As System.Windows.Forms.TextBox
    Friend WithEvents buttonTableLayout As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents exitButton As System.Windows.Forms.Button
    Friend WithEvents submitButton As System.Windows.Forms.Button
    Friend WithEvents clearButton As System.Windows.Forms.Button
    Friend WithEvents rsltLbl As System.Windows.Forms.Label
    Friend WithEvents vePictureBox As System.Windows.Forms.PictureBox

End Class
