﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.BlueButton = New System.Windows.Forms.Button()
        Me.GreenButton = New System.Windows.Forms.Button()
        Me.PinkButton = New System.Windows.Forms.Button()
        Me.BrownButton = New System.Windows.Forms.Button()
        Me.YellowButton = New System.Windows.Forms.Button()
        Me.PurpleButton = New System.Windows.Forms.Button()
        Me.GrayButton = New System.Windows.Forms.Button()
        Me.OrangeButton = New System.Windows.Forms.Button()
        Me.RedButton = New System.Windows.Forms.Button()
        Me.ClickLabel = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.FontButton = New System.Windows.Forms.Button()
        Me.PrintButton = New System.Windows.Forms.Button()
        Me.StartOButton = New System.Windows.Forms.Button()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.PrintForm1 = New Microsoft.VisualBasic.PowerPacks.Printing.PrintForm(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.95833!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.04167!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 97.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.BlueButton, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.GreenButton, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.PinkButton, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.BrownButton, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.YellowButton, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.PurpleButton, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.GrayButton, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.OrangeButton, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.RedButton, 0, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(48, 65)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.88679!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.11321!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(281, 158)
        Me.TableLayoutPanel1.TabIndex = 2
        '
        'BlueButton
        '
        Me.BlueButton.BackColor = System.Drawing.Color.LightGray
        Me.BlueButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BlueButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BlueButton.Location = New System.Drawing.Point(93, 3)
        Me.BlueButton.Name = "BlueButton"
        Me.BlueButton.Size = New System.Drawing.Size(87, 49)
        Me.BlueButton.TabIndex = 2
        Me.BlueButton.Text = "&Blue"
        Me.BlueButton.UseVisualStyleBackColor = False
        '
        'GreenButton
        '
        Me.GreenButton.BackColor = System.Drawing.Color.LightGray
        Me.GreenButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GreenButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GreenButton.Location = New System.Drawing.Point(186, 3)
        Me.GreenButton.Name = "GreenButton"
        Me.GreenButton.Size = New System.Drawing.Size(85, 49)
        Me.GreenButton.TabIndex = 3
        Me.GreenButton.Text = "&Green"
        Me.GreenButton.UseVisualStyleBackColor = False
        '
        'PinkButton
        '
        Me.PinkButton.BackColor = System.Drawing.Color.LightGray
        Me.PinkButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.PinkButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PinkButton.Location = New System.Drawing.Point(186, 58)
        Me.PinkButton.Name = "PinkButton"
        Me.PinkButton.Size = New System.Drawing.Size(85, 45)
        Me.PinkButton.TabIndex = 6
        Me.PinkButton.Text = "&Pink"
        Me.PinkButton.UseVisualStyleBackColor = False
        '
        'BrownButton
        '
        Me.BrownButton.BackColor = System.Drawing.Color.LightGray
        Me.BrownButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BrownButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BrownButton.Location = New System.Drawing.Point(93, 58)
        Me.BrownButton.Name = "BrownButton"
        Me.BrownButton.Size = New System.Drawing.Size(87, 45)
        Me.BrownButton.TabIndex = 5
        Me.BrownButton.Text = "Br&own"
        Me.BrownButton.UseVisualStyleBackColor = False
        '
        'YellowButton
        '
        Me.YellowButton.BackColor = System.Drawing.Color.LightGray
        Me.YellowButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.YellowButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.YellowButton.Location = New System.Drawing.Point(3, 58)
        Me.YellowButton.Name = "YellowButton"
        Me.YellowButton.Size = New System.Drawing.Size(84, 45)
        Me.YellowButton.TabIndex = 4
        Me.YellowButton.Text = "&Yellow"
        Me.YellowButton.UseVisualStyleBackColor = False
        '
        'PurpleButton
        '
        Me.PurpleButton.BackColor = System.Drawing.Color.LightGray
        Me.PurpleButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.PurpleButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PurpleButton.Location = New System.Drawing.Point(3, 109)
        Me.PurpleButton.Name = "PurpleButton"
        Me.PurpleButton.Size = New System.Drawing.Size(84, 46)
        Me.PurpleButton.TabIndex = 7
        Me.PurpleButton.Text = "P&urple"
        Me.PurpleButton.UseVisualStyleBackColor = False
        '
        'GrayButton
        '
        Me.GrayButton.BackColor = System.Drawing.Color.LightGray
        Me.GrayButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GrayButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrayButton.Location = New System.Drawing.Point(93, 109)
        Me.GrayButton.Name = "GrayButton"
        Me.GrayButton.Size = New System.Drawing.Size(87, 46)
        Me.GrayButton.TabIndex = 8
        Me.GrayButton.Text = "Gr&ay"
        Me.GrayButton.UseVisualStyleBackColor = False
        '
        'OrangeButton
        '
        Me.OrangeButton.BackColor = System.Drawing.Color.LightGray
        Me.OrangeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.OrangeButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OrangeButton.Location = New System.Drawing.Point(186, 109)
        Me.OrangeButton.Name = "OrangeButton"
        Me.OrangeButton.Size = New System.Drawing.Size(85, 46)
        Me.OrangeButton.TabIndex = 9
        Me.OrangeButton.Text = "&Orange"
        Me.OrangeButton.UseVisualStyleBackColor = False
        '
        'RedButton
        '
        Me.RedButton.BackColor = System.Drawing.Color.LightGray
        Me.RedButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RedButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RedButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RedButton.Location = New System.Drawing.Point(3, 3)
        Me.RedButton.Name = "RedButton"
        Me.RedButton.Size = New System.Drawing.Size(84, 49)
        Me.RedButton.TabIndex = 1
        Me.RedButton.Text = "&Red"
        Me.RedButton.UseVisualStyleBackColor = False
        '
        'ClickLabel
        '
        Me.ClickLabel.AutoSize = True
        Me.ClickLabel.BackColor = System.Drawing.Color.Transparent
        Me.ClickLabel.Font = New System.Drawing.Font("Modern No. 20", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClickLabel.Location = New System.Drawing.Point(47, 41)
        Me.ClickLabel.Name = "ClickLabel"
        Me.ClickLabel.Size = New System.Drawing.Size(174, 21)
        Me.ClickLabel.TabIndex = 4
        Me.ClickLabel.Text = "Click a Color Button:"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel2.ColumnCount = 4
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 87.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 84.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 71.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.ExitButton, 3, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.FontButton, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.PrintButton, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.StartOButton, 0, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(26, 239)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(330, 29)
        Me.TableLayoutPanel2.TabIndex = 5
        '
        'ExitButton
        '
        Me.ExitButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.ExitButton.Location = New System.Drawing.Point(262, 3)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(65, 22)
        Me.ExitButton.TabIndex = 13
        Me.ExitButton.Text = "&Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'FontButton
        '
        Me.FontButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.FontButton.Location = New System.Drawing.Point(178, 3)
        Me.FontButton.Name = "FontButton"
        Me.FontButton.Size = New System.Drawing.Size(78, 22)
        Me.FontButton.TabIndex = 12
        Me.FontButton.Text = "&Font"
        Me.FontButton.UseVisualStyleBackColor = True
        '
        'PrintButton
        '
        Me.PrintButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.PrintButton.Location = New System.Drawing.Point(91, 3)
        Me.PrintButton.Name = "PrintButton"
        Me.PrintButton.Size = New System.Drawing.Size(81, 22)
        Me.PrintButton.TabIndex = 11
        Me.PrintButton.Text = "Pr&int"
        Me.PrintButton.UseVisualStyleBackColor = True
        '
        'StartOButton
        '
        Me.StartOButton.AccessibleDescription = ""
        Me.StartOButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.StartOButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.StartOButton.Location = New System.Drawing.Point(3, 3)
        Me.StartOButton.Name = "StartOButton"
        Me.StartOButton.Size = New System.Drawing.Size(80, 22)
        Me.StartOButton.TabIndex = 10
        Me.StartOButton.Text = "&Start Over"
        Me.StartOButton.UseVisualStyleBackColor = True
        '
        'PrintForm1
        '
        Me.PrintForm1.DocumentName = "document"
        Me.PrintForm1.Form = Me
        Me.PrintForm1.PrintAction = System.Drawing.Printing.PrintAction.PrintToPrinter
        Me.PrintForm1.PrinterSettings = CType(resources.GetObject("PrintForm1.PrinterSettings"), System.Drawing.Printing.PrinterSettings)
        Me.PrintForm1.PrintFileName = Nothing
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.COLOR_GAME.My.Resources.Resources.bg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(384, 280)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.ClickLabel)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "Form1"
        Me.Text = "Color Game"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents BlueButton As System.Windows.Forms.Button
    Friend WithEvents GreenButton As System.Windows.Forms.Button
    Friend WithEvents PinkButton As System.Windows.Forms.Button
    Friend WithEvents BrownButton As System.Windows.Forms.Button
    Friend WithEvents YellowButton As System.Windows.Forms.Button
    Friend WithEvents PurpleButton As System.Windows.Forms.Button
    Friend WithEvents GrayButton As System.Windows.Forms.Button
    Friend WithEvents OrangeButton As System.Windows.Forms.Button
    Friend WithEvents RedButton As System.Windows.Forms.Button
    Friend WithEvents ClickLabel As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents ExitButton As System.Windows.Forms.Button
    Friend WithEvents FontButton As System.Windows.Forms.Button
    Friend WithEvents PrintButton As System.Windows.Forms.Button
    Friend WithEvents StartOButton As System.Windows.Forms.Button
    Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents PrintForm1 As Microsoft.VisualBasic.PowerPacks.Printing.PrintForm

End Class
