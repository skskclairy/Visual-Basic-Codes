﻿Public Class Form1

    Private Sub FontButton_Click(sender As Object, e As EventArgs) Handles FontButton.Click
        FontDialog1.Font = FontButton.Font
        FontDialog1.ShowDialog()
        RedButton.Font = FontDialog1.Font
        BlueButton.Font = FontDialog1.Font
        GreenButton.Font = FontDialog1.Font
        YellowButton.Font = FontDialog1.Font
        BrownButton.Font = FontDialog1.Font
        PinkButton.Font = FontDialog1.Font
        PurpleButton.Font = FontDialog1.Font
        GrayButton.Font = FontDialog1.Font
        OrangeButton.Font = FontDialog1.Font
        StartOButton.Font = FontDialog1.Font
        PrintButton.Font = FontDialog1.Font
        FontButton.Font = FontDialog1.Font
        ExitButton.Font = FontDialog1.Font
    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Me.Close()
    End Sub

    Private Sub RedButton_Click(sender As Object, e As EventArgs) Handles RedButton.Click
        ColorDialog1.Color = RedButton.BackColor
        ColorDialog1.ShowDialog()
        RedButton.BackColor = ColorDialog1.Color
    End Sub

    Private Sub BlueButton_Click(sender As Object, e As EventArgs) Handles BlueButton.Click
        ColorDialog1.Color = BlueButton.BackColor
        ColorDialog1.ShowDialog()
        BlueButton.BackColor = ColorDialog1.Color
    End Sub

    Private Sub GreenButton_Click(sender As Object, e As EventArgs) Handles GreenButton.Click
        ColorDialog1.Color = GreenButton.BackColor()
        ColorDialog1.ShowDialog()
        GreenButton.BackColor = ColorDialog1.Color
    End Sub

    Private Sub YellowButton_Click(sender As Object, e As EventArgs) Handles YellowButton.Click
        ColorDialog1.Color = YellowButton.BackColor()
        ColorDialog1.ShowDialog()
        YellowButton.BackColor = ColorDialog1.Color
    End Sub

    Private Sub BrownButton_Click(sender As Object, e As EventArgs) Handles BrownButton.Click
        ColorDialog1.Color = BrownButton.BackColor
        ColorDialog1.ShowDialog()
        BrownButton.BackColor = ColorDialog1.Color
    End Sub

    Private Sub PinkButton_Click(sender As Object, e As EventArgs) Handles PinkButton.Click
        ColorDialog1.Color = PinkButton.BackColor
        ColorDialog1.ShowDialog()
        PinkButton.BackColor = ColorDialog1.Color
    End Sub

    Private Sub PurpleButton_Click(sender As Object, e As EventArgs) Handles PurpleButton.Click
        ColorDialog1.Color = PurpleButton.BackColor
        ColorDialog1.ShowDialog()
        PurpleButton.BackColor = ColorDialog1.Color
    End Sub

    Private Sub GrayButton_Click(sender As Object, e As EventArgs) Handles GrayButton.Click
        ColorDialog1.Color = GrayButton.BackColor
        ColorDialog1.ShowDialog()
        GrayButton.BackColor = ColorDialog1.Color
    End Sub

    Private Sub OrangeButton_Click(sender As Object, e As EventArgs) Handles OrangeButton.Click
        ColorDialog1.Color = OrangeButton.BackColor
        ColorDialog1.ShowDialog()
        OrangeButton.BackColor = ColorDialog1.Color
    End Sub

    Private Sub PrintButton_Click(sender As Object, e As EventArgs) Handles PrintButton.Click
        PrintForm1.PrintAction = Printing.PrintAction.PrintToPreview
        PrintForm1.Print()
    End Sub

    Private Sub StartOButton_Click(sender As Object, e As EventArgs) Handles StartOButton.Click
        RedButton.BackColor = Color.LightGray
        BlueButton.BackColor = Color.LightGray
        GreenButton.BackColor = Color.LightGray
        YellowButton.BackColor = Color.LightGray
        BrownButton.BackColor = Color.LightGray
        PinkButton.BackColor = Color.LightGray
        PurpleButton.BackColor = Color.LightGray
        GrayButton.BackColor = Color.LightGray
        OrangeButton.BackColor = Color.LightGray
    End Sub
End Class
